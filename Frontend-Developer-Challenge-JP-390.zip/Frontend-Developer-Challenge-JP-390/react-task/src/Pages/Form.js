import React, { Component } from 'react'

class Form extends Component {
  render() {
    return (
      <div className="form">
        <div className="container">
            <div className="box-form">
                <h2 className='form-title'>Form</h2>
                    <form className="control">
                        <input type="text" name="name" placeholder="Name" />
                        <input type="password" name="password" placeholder="password" />
                        <input type="submit " name="submit" />
                    </form>
            </div>
        </div>
      </div>
    )
  }
}

export default Form