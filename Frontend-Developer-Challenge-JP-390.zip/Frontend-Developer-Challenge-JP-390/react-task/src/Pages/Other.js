import React, { Component } from 'react'

class Other extends Component {
  render() {
    return (
      <div className="other">
    
      </div>
    )
  }
}

export default Other