import React, { Component } from 'react'
import { Switch, Route } from 'react-router-dom'
import Form from './Pages/Form'
import Other from './Pages/Other'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Switch>
          <Route exact path= '/' render={() => (
            <Form />)} />
          <Route exact path='/Other' render={() => (
            <Other/> )} />
        </Switch>              
      </div>
    )
  }
}

export default App;
