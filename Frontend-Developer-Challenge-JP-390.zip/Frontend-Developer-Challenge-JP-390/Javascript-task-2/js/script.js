
/* global console*/

const test = document.getElementById("test");

function MyRand(min , max) {
    'use strict';
    return Math.floor(Math.random() * (max-min +1)) + min;
}

function draw() {
    'use strict';
    let min = 1;
    let max = 5;
    let countRand =  MyRand(min , max);
    let letter = 'L';
    let longLetter = '';
    

    for(var x=1; x <= countRand; x++) {
        longLetter +=  letter;

        if(x==countRand) {break;}
        
        console.log(letter + '\n')
        test.innerHTML += letter + "<br>";
    }

    console.log(longLetter);
    test.innerHTML += longLetter;
};

draw()