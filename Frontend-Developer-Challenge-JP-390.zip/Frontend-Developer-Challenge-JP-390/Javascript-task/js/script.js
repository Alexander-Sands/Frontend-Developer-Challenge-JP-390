/* global console*/

const test = document.getElementById('test');


test.onclick = function (e) {
    "use strict";
    
    // console.log(test.clientWidth)
    // console.log(test.clientHeight)
    console.log(this.clientWidth)
    console.log(test.clientHeight)
    console.log(e.value)
    console.log(e.clientHeight)
}